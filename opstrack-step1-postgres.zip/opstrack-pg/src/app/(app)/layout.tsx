import Link from 'next/link'
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/session'
import { logout } from './actions'

// Shared frame for every signed-in page: sidebar + top bar.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()
  if (!user) redirect('/login')

  return (
    <div className="min-h-screen flex bg-[#EEF2F3] text-[#12262B]">
      <aside className="w-56 shrink-0 bg-[#12262B] text-white p-5 hidden md:block">
        <div className="text-xl font-semibold mb-8">OpsTrack</div>
        <nav className="space-y-1 text-[15px]">
          <Link href="/" className="block rounded px-3 py-2 bg-white/10">Home</Link>
          <Link href="/projects" className="block rounded px-3 py-2 hover:bg-white/10">Projects</Link>
          <Link href="/tasks" className="block rounded px-3 py-2 hover:bg-white/10">Tasks</Link>
        </nav>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="flex items-center justify-end gap-4 border-b border-[#D5DEE0] bg-white px-6 py-3">
          <span className="text-sm text-[#4B6168]">{user.name}</span>
          <form action={logout}>
            <button className="text-sm text-[#4B6168] hover:text-[#12262B] underline-offset-4 hover:underline">
              Sign out
            </button>
          </form>
        </header>
        <main className="p-6">{children}</main>
      </div>
    </div>
  )
}
