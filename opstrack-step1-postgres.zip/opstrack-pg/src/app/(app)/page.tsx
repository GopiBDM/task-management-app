import Link from 'next/link'
import { pool } from '@/lib/db'
import { getCurrentUser } from '@/lib/session'

type MyTask = {
  id: string
  title: string
  due_date: string
  priority: string
  status: string
  project_name: string
  overdue: boolean
}

export default async function HomePage() {
  const user = (await getCurrentUser())!

  // One query for the three counts.
  const counts = await pool.query(`
    select
      (select count(*)::int from projects where status = 'Active')                          as projects,
      (select count(*)::int from tasks where status <> 'Done')                              as open_tasks,
      (select count(*)::int from tasks where status <> 'Done' and due_date < current_date)  as overdue
  `)

  // Open tasks assigned to the signed-in user. $1 is filled in safely with user.id.
  const mine = await pool.query<MyTask>(
    `select t.id, t.title,
            to_char(t.due_date, 'YYYY-MM-DD') as due_date,
            t.priority, t.status,
            p.name as project_name,
            (t.due_date < current_date) as overdue
       from tasks t
       join projects p on p.id = t.project_id
      where t.assignee_id = $1 and t.status <> 'Done'
      order by t.due_date
      limit 8`,
    [user.id]
  )

  const c = counts.rows[0]
  const stats = [
    { label: 'Active projects', value: c.projects, href: '/projects', warn: false },
    { label: 'Open tasks', value: c.open_tasks, href: '/tasks', warn: false },
    { label: 'Overdue tasks', value: c.overdue, href: '/tasks?filter=overdue', warn: true },
  ]

  return (
    <div className="max-w-5xl">
      <h1 className="text-2xl font-semibold">Home</h1>

      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <Link
            key={s.label}
            href={s.href}
            className="rounded-lg border border-[#D5DEE0] bg-white p-4 hover:border-[#0F766E]"
          >
            <div className={`text-3xl font-semibold ${s.warn && s.value > 0 ? 'text-red-700' : ''}`}>
              {s.value}
            </div>
            <div className="mt-1 text-sm text-[#4B6168]">{s.label}</div>
          </Link>
        ))}
      </div>

      <section className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Assigned to you</h2>
          <Link href="/tasks" className="text-sm text-[#0F766E] hover:underline">
            View all tasks
          </Link>
        </div>

        <div className="mt-3 rounded-lg border border-[#D5DEE0] bg-white overflow-x-auto">
          {mine.rows.length > 0 ? (
            <table className="w-full text-sm">
              <thead className="text-left text-[#4B6168] border-b border-[#D5DEE0]">
                <tr>
                  <th className="px-4 py-2 font-medium">Task</th>
                  <th className="px-4 py-2 font-medium">Project</th>
                  <th className="px-4 py-2 font-medium">Due</th>
                  <th className="px-4 py-2 font-medium">Priority</th>
                  <th className="px-4 py-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {mine.rows.map((t) => (
                  <tr key={t.id} className="border-b last:border-0 border-[#E6ECED]">
                    <td className="px-4 py-2">
                      <Link href={`/tasks/${t.id}`} className="text-[#0F766E] hover:underline">
                        {t.title}
                      </Link>
                    </td>
                    <td className="px-4 py-2">{t.project_name}</td>
                    <td className={`px-4 py-2 ${t.overdue ? 'text-red-700' : ''}`}>{t.due_date}</td>
                    <td className="px-4 py-2">{t.priority}</td>
                    <td className="px-4 py-2">{t.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="p-6 text-[#4B6168]">
              No open tasks are assigned to you. Create a project, then add a task to it.
            </p>
          )}
        </div>
      </section>
    </div>
  )
}
