'use client'

import { useActionState } from 'react'
import { login } from './actions'

export default function LoginPage() {
  const [state, formAction, pending] = useActionState(login, undefined)

  return (
    <main className="min-h-screen grid place-items-center bg-[#EEF2F3] px-4">
      <div className="w-full max-w-sm">
        <h1 className="text-3xl font-semibold tracking-tight text-[#12262B]">OpsTrack</h1>
        <p className="mt-1 mb-8 text-[#4B6168]">Sign in to manage your projects and tasks.</p>

        <form
          action={formAction}
          className="space-y-4 rounded-lg bg-white p-6 shadow-sm border border-[#D5DEE0]"
        >
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-[#12262B]">
              Work email <span className="text-red-600">*</span>
            </label>
            <input
              id="email"
              name="email"
              type="email"
              required
              autoComplete="email"
              className="mt-1 w-full rounded-md border border-[#B8C6C9] px-3 py-2 outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/25"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-[#12262B]">
              Password <span className="text-red-600">*</span>
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              autoComplete="current-password"
              className="mt-1 w-full rounded-md border border-[#B8C6C9] px-3 py-2 outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/25"
            />
          </div>

          {state?.error && (
            <p role="alert" className="text-sm text-red-700">
              {state.error}
            </p>
          )}

          <button
            type="submit"
            disabled={pending}
            className="w-full rounded-md bg-[#0F766E] py-2 font-medium text-white hover:bg-[#0B5F58] disabled:opacity-60"
          >
            {pending ? 'Signing in...' : 'Sign in'}
          </button>
        </form>
      </div>
    </main>
  )
}
